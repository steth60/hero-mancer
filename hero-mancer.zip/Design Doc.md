# Design Document

## JSDoc Issues

1. **Incomplete Parameter Documentation**

   - Many JSDoc comments are missing @param tags for all parameters, especially in methods like `_preparePartContext` in HeroMancer.js.

2. **Missing Return Type Annotations**

   - Several functions are missing @returns tags or have incorrect return types.

3. **Inconsistent JSDoc Style**

   - Some files use `@param {Type} name - Description` while others use `@param {Type} name Description` without the dash.

4. **Unused Type Definitions**

   - Some custom types are defined but not used consistently throughout the codebase.

5. **Better Type Specificity Needed**
   - Many functions use generic types like `object` or `any` where more specific types would be appropriate.

## Redundant CSS

1. **Duplicate Selectors**

   - Several selectors in hero-mancer.css are defined multiple times with different properties, which could be combined.

2. **Repeated Properties**

   - Common styling patterns like flexbox setups are repeated across many selectors instead of using utility classes.

3. **Media Query Duplication**

   - Similar media query breakpoints are repeated with overlapping rules.

4. **Inconsistent Spacing Units**

   - There's a mix of rem, em, and px units where standardization would be helpful.

5. **Overspecified Selectors**
   - Some selectors are unnecessarily long and specific, which makes the CSS harder to maintain.
